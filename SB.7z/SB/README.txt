Instances are organized as follows

- number of customers(the starting depot and ending depot are not included)
- array of demands (the first one and the last one is 0 since they are depots)
- distance matrix
- travel time matrix