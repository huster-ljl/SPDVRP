Name of the instance ("Name")；

Number of vehicles available ("|K|")；

Number of customers ("n")；

Vehicle capacity ("Q")；

Cost of the best solution found ("z*") by EXM；

Number of routes composing the solution ("rt")；

Percentage deviation of the upper bound computed by the primal heuristic (\%UB"), computed
as 100.0 X UB/z* where UB is the value of the upper bound；

Percentage deviation of lower bound derived from the LP-relaxation
("%LB"), computed as 100.0 X LB/z* where LB is the value of the lower bound；

Percentage deviation of lower bound obtained from the column-and-row generation procedure
("%LBr"), computed as 100.0 X LBr/z* where LBr is the value of the lower bound；

Time in seconds spent to compute the lower bound at the root node ("tr")；

Total computing time in seconds ("t")。